package utils;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Common {
	String configFile = "config.properties";

	private WebDriver driver; 

	public void setupBrowser() {
		String browser, url;

		ReadFiles readConfigFile = new ReadFiles();
		Properties prop = readConfigFile.readPropertyFile(configFile);
		browser = prop.getProperty("browser");
		url = prop.getProperty("url");


		if(browser.equalsIgnoreCase("chrome")) {
			this.driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			this.driver = new FirefoxDriver();
		}
		else if(browser.equalsIgnoreCase("edge")) {
			this.driver = new EdgeDriver();
		}
		else {
			System.out.println("Driver object is not provided or valid, hence not invoking the browser");
			System.exit(0);
		}

		this.driver.manage().window().maximize();

		if(url!="")
			this.driver.get(url);
		else {
			System.out.println("url is not provided and hence quiting the test run");
			quitBrowser();			
		}
	}

	public void quitBrowser() {
		if(driver!=null)
			this.driver.quit();
	}

	public WebDriver getDriver() {
		return this.driver;
	}

}
